module.exports = {
  'approval': {
    'num': '6289629967066',
    'text': "setujui",
    'set': "👀 Harus mendapatkan persetujuan oleh creator script, Jika ingin memakai script ini",
    'greet': "*Disetujui Oleh Creator, Silahkan Restart Panel Atau Run Ulang script* ☠️ "
  },
  'creatorScript': '6289629967066',
  'filePath': "./data/approval",
  'checkFilePath': "./rafatharcode.js",
  'codeToDetect': 'connectToWhatsApp();'
};