/*
Jangan Hapus Wm Bang 

*YouTube Download MP4 Plugins Esm*

Bisa Atur Resolution 

*[Sumber]*
https://whatsapp.com/channel/0029Vb3u2awADTOCXVsvia28

*/

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const handler = async (m, { vreden, text }) => {
    if (!text) return m.reply('Mana link YouTube-nya?');

    const youtubeUrl = text;
    const resolution = '1080';
    const endpoint = `https://ytcdn.project-rian.my.id/download?url=${encodeURIComponent(youtubeUrl)}&resolution=${resolution}`;

    try {
        m.reply('Tunggu bentar, lagi proses download...');

        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

        const originalPath = path.join(tmpDir, `video_${Date.now()}.mp4`);
        const convertedPath = path.join(tmpDir, `converted_${Date.now()}.mp4`);

        const response = await axios({
            method: 'GET',
            url: endpoint,
            responseType: 'arraybuffer',
        });

        fs.writeFileSync(originalPath, Buffer.from(response.data));

        exec(`ffmpeg -i "${originalPath}" -c:v libx264 -preset fast -c:a aac "${convertedPath}"`, async (err) => {
            if (err) {
                m.reply('Gagal konversi video.');
                return;
            }

            await vreden.sendMessage(m.chat, { video: { url: convertedPath } });

            fs.unlinkSync(originalPath);
            fs.unlinkSync(convertedPath);
        });
    } catch (error) {
        m.reply('Yah, gagal download. Coba lagi nanti.');
    }
};

handler.help = ['ytv3'];
handler.tags = ["downloader"]
handler.command = ['ytv3'];

module.exports = handler;